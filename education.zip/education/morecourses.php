<!DOCTYPE html>
<html>
<head>
	<title>More Courses Offered</title>
	<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">			
			<link rel="stylesheet" href="css/jquery-ui.css">			
			<link rel="stylesheet" href="css/main.css">
</head>
<body>
 <!-- Start popular-courses Area --> 
			<section class="popular-courses-area section-gap courses-page">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content pb-70 col-lg-8">
							<div class="title text-center">
								<h1 class="mb-10"> More KCSE Courses Offered </h1>
								<p>There is a moment in the life of any aspiring.</p>
							</div>
						</div>
					</div>						
					<div class="row">
						<div class="single-popular-carusel col-lg-3 col-md-6">
							<div class="thumb-wrap relative">
								<div class="thumb relative">
									<div class="overlay overlay-bg"></div>	
									<img class="img-fluid" src="img/p1.jpg" alt="">
								</div>
								<div class="meta d-flex justify-content-between">
									<p><span class="lnr lnr-users"></span>  <span class="lnr lnr-bubble"></span></p>
									<h4></h4>
								</div>									
							</div>
							<div class="details">
								<a href="course-details.html">
									<h4>
										Biology

									</h4>
								</a>
								<p>
									When television was young, there was a hugely popular show based on the still popular fictional characte										
								</p>
							</div>
						</div>	
						<div class="single-popular-carusel col-lg-3 col-md-6">
							<div class="thumb-wrap relative">
								<div class="thumb relative">
									<div class="overlay overlay-bg"></div>	
									<img class="img-fluid" src="img/p2.jpg" alt="">
								</div>
								<div class="meta d-flex justify-content-between">
									<p><span class="lnr lnr-users"></span>  <span class="lnr lnr-bubble"></span></p>
									<h4></h4>
								</div>									
							</div>
							<div class="details">
								<a href="course-details.html">
									<h4>
									Business Studies
									</h4>
								</a>
								<p>
									When television was young, there was a hugely popular show based on the still popular fictional characte										
								</p>
							</div>
						</div>	
						<div class="single-popular-carusel col-lg-3 col-md-6">
							<div class="thumb-wrap relative">
								<div class="thumb relative">
									<div class="overlay overlay-bg"></div>	
									<img class="img-fluid" src="img/p3.jpg" alt="">
								</div>
								<div class="meta d-flex justify-content-between">
									<p><span class="lnr lnr-users"></span> <span class="lnr lnr-bubble"></span></p>
									<h4></h4>
								</div>									
							</div>
							<div class="details">
								<a href="course-details.html">
									<h4>
									Home Science
									</h4>
								</a>
								<p>
									When television was young, there was a hugely popular show based on the still popular fictional characte										
								</p>
							</div>
						</div>	
						<div class="single-popular-carusel col-lg-3 col-md-6">
							<div class="thumb-wrap relative">
								<div class="thumb relative">
									<div class="overlay overlay-bg"></div>	
									<img class="img-fluid" src="img/p4.jpg" alt="">
								</div>
								<div class="meta d-flex justify-content-between">
									<p><span class="lnr lnr-users"></span>  <span class="lnr lnr-bubble"></span></p>
									<h4>Music</h4>
								</div>									
							</div>
							<div class="details">
								<a href="course-details.html">
									<h4>
										Art and Design
									</h4>
								</a>
								<p>
									When television was young, there was a hugely popular show based on the still popular fictional characte										
								</p>
							</div>
						</div>
						<div class="single-popular-carusel col-lg-3 col-md-6">
							<div class="thumb-wrap relative">
								<div class="thumb relative">
									<div class="overlay overlay-bg"></div>	
									<img class="img-fluid" src="img/p1.jpg" alt="">
								</div>
								<div class="meta d-flex justify-content-between">
									<p><span class="lnr lnr-users"></span>  <span class="lnr lnr-bubble"></span></p>
									<h4></h4>
								</div>									
							</div>
							<div class="details">
								<a href="course-details.html">
									<h4>
									IRE
									</h4>
								</a>
								<p>
									When television was young, there was a hugely popular show based on the still popular fictional characte										
								</p>
							</div>
						</div>	
						<div class="single-popular-carusel col-lg-3 col-md-6">
							<div class="thumb-wrap relative">
								<div class="thumb relative">
									<div class="overlay overlay-bg"></div>	
									<img class="img-fluid" src="img/p2.jpg" alt="">
								</div>
								<div class="meta d-flex justify-content-between">
									<p><span class="lnr lnr-users"></span>  <span class="lnr lnr-bubble"></span></p>
									<h4></h4>
								</div>									
							</div>
							<div class="details">
								<a href="course-details.html">
									<h4>
										Computer Studies
									</h4>
								</a>
								<p>
									When television was young, there was a hugely popular show based on the still popular fictional characte										
								</p>
							</div>
						</div>	
						<div class="single-popular-carusel col-lg-3 col-md-6">
							<div class="thumb-wrap relative">
								<div class="thumb relative">
									<div class="overlay overlay-bg"></div>	
									<img class="img-fluid" src="img/p3.jpg" alt="">
								</div>
								<div class="meta d-flex justify-content-between">
									<p><span class="lnr lnr-users"></span>  <span class="lnr lnr-bubble"></span></p>
									<h4></h4>
								</div>									
							</div>
							<div class="details">
								<a href="course-details.html">
									<h4>
										Geography
									</h4>
								</a>
								<p>
									When television was young, there was a hugely popular show based on the still popular fictional characte										
								</p>
							</div>
						</div>	
						<div class="single-popular-carusel col-lg-3 col-md-6">
							<div class="thumb-wrap relative">
								<div class="thumb relative">
									<div class="overlay overlay-bg"></div>	
									<img class="img-fluid" src="img/p4.jpg" alt="">
								</div>
								<div class="meta d-flex justify-content-between">
									<p><span class="lnr lnr-users"></span>  <span class="lnr lnr-bubble"></span>35</p>
									<h4></h4>
								</div>									
							</div>
							<div class="details">
								<a href="course-details.html">
									<h4>
										History
									</h4>
								</a>
								<p>
									When television was young, there was a hugely popular show based on the still popular fictional characte										
								</p>
							</div>
						</div>								
						<a href="kcse.html" class="primary-btn text-uppercase mx-auto">Back</a>													
					</div>
				</div>	
			</section>
			<!-- End popular-courses Area -->			

</body>
</html>